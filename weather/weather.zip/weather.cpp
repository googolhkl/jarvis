#include"jarvis.h"
#include"weather.h"
int main(void)
{
	weathermake(7);
			
}



